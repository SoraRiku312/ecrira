package com.williamtburch.sora.ecrira.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CharacterBaseHelper extends SQLiteOpenHelper{
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "characterBase.db";

    public CharacterBaseHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + CharacterDbSchema.CharacterTable.NAME + "(" +
            "_id integer primary key autoincrement, " +
            CharacterDbSchema.CharacterTable.Cols.UUID + "," +
                        CharacterDbSchema.CharacterTable.Cols.FNAME + ", " +
                        CharacterDbSchema.CharacterTable.Cols.LNAME + ", " +
                        CharacterDbSchema.CharacterTable.Cols.AGE  +
                ")"
        );
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}
}
