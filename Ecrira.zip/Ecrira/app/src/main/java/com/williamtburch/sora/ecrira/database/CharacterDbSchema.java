package com.williamtburch.sora.ecrira.database;

public class CharacterDbSchema {
    public static final class CharacterTable{
        public static final String NAME = "characters";

        public static final class Cols{
            public static final String UUID = "uuid";
            public static final String FNAME = "firstname";
            public static final String LNAME = "lastname";
            public static final String AGE = "age";
        }
    }
}
