package com.williamtburch.sora.ecrira.database;

import com.williamtburch.sora.ecrira.Character;
import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.UUID;

public class CharacterCursorWrapper extends CursorWrapper {
    public CharacterCursorWrapper(Cursor cursor){
        super(cursor);
    }

    public Character getCharacter(){
        String uuidString = getString(getColumnIndex(CharacterDbSchema.CharacterTable.Cols.UUID));
        String firstName = getString(getColumnIndex(CharacterDbSchema.CharacterTable.Cols.FNAME));
        String lastName = getString(getColumnIndex(CharacterDbSchema.CharacterTable.Cols.LNAME));
        String age = getString(getColumnIndex(CharacterDbSchema.CharacterTable.Cols.AGE));

        Character character = new Character(UUID.fromString(uuidString));
        character.setFirstName(firstName);
        character.setLastName(lastName);
        character.setAge(Integer.valueOf(age));



        return character;
    }
}
