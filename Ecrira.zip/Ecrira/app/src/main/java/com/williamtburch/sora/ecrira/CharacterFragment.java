package com.williamtburch.sora.ecrira;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;
import com.williamtburch.sora.ecrira.databinding.FragmentCharacterBinding;

import java.util.UUID;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import static android.app.Activity.RESULT_OK;

public class CharacterFragment extends Fragment {

    private static final String ARG_CHARACTER_ID = "crime_id";
    static final int RESULT_LOAD_IMG = 1;

    private FragmentCharacterBinding binding;

    private GridLayoutManager layoutManager;



    public static CharacterFragment newInstance(UUID characterId){
        Bundle args = new Bundle();
        args.putSerializable(ARG_CHARACTER_ID, characterId);

        CharacterFragment fragment = new CharacterFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private Character mCharacter;
    private EditText mNameField;
    private EditText mAgeField;
    private Button mAddImageButton;
    private ImageView mImageView;


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        UUID characterId = (UUID)getArguments().getSerializable(ARG_CHARACTER_ID);
        mCharacter = CharacterLab.get(getActivity()).getCharacter(characterId);


    }

    @Override
    public void onPause(){
        super.onPause();
        CharacterLab.get(getActivity()).updateCharacter(mCharacter);

    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
//        View v = inflater.inflate(R.layout.fragment_character, container, false);


        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_character, container, false);

        binding.setCharacter(mCharacter);


        mNameField = binding.characterName;
        mAgeField = binding.characterAge;


        View v = binding.getRoot();




        mNameField = (EditText)v.findViewById(R.id.character_name);
        mNameField.setText(mCharacter.getFirstName()); ////make a get full name thing
        mNameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mCharacter.setFirstName(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                //
            }
        });

        mAgeField = (EditText)v.findViewById(R.id.character_age);
        mAgeField.setText(mCharacter.getAgeAsString());
        mAgeField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()!=0){
                    mCharacter.setAgeAsString(s.toString());
                }
            }
        });

        mAddImageButton = (Button)v.findViewById(R.id.add_image_button);
        mAddImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, RESULT_LOAD_IMG);
            }
        });

        mImageView = (ImageView)v.findViewById(R.id.character_image_view);

        return v;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK && requestCode == RESULT_LOAD_IMG){
                final Uri imageUri = data.getData();
                Picasso.get().load(imageUri).resize(mImageView.getWidth(), mImageView.getHeight()).into(mImageView);
        }

    }


    //    private class CharacterAdapter extends GroupAdapter<CharacterHolder>{
//
//        private List<Character> mCharacters;
//
//        public CharacterAdapter(List<Character> characters){
//            mCharacters = characters;
//        }
//
//        public void setCharacters(List<Character> characters){
//            mCharacters = characters;
//        }
//
//    }
//}


}
