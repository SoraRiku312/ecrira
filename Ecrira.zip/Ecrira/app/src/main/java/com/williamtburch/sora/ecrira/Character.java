package com.williamtburch.sora.ecrira;

import java.util.UUID;

public class Character {


    private UUID mID;
    private String mFirstName;
    private String mLastName;
    private int mAge;

    public Character(){
        mID = UUID.randomUUID();

    }

    public Character(UUID id){
        mID = id;
    }

    public String getFirstName() {
        return mFirstName;
    }

    public void setFirstName(String firstName) {
        mFirstName = firstName;
    }

    public String getLastName() {
        return mLastName;
    }

    public void setLastName(String lastName) {
        mLastName = lastName;
    }

    public int getAge() {
        return mAge;
    }
    public String getAgeAsString(){
        return String.valueOf(mAge);
    }

    public void setAge(int age) {
        mAge = age;
    }
    public void setAgeAsString(String age){mAge = Integer.valueOf(age);}


    public UUID getID() {
        return mID;
    }

    public void setID(UUID ID) {
        mID = ID;
    }
}
