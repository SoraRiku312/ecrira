package com.williamtburch.sora.ecrira;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;


import com.williamtburch.sora.ecrira.database.CharacterBaseHelper;
import com.williamtburch.sora.ecrira.database.CharacterCursorWrapper;
import com.williamtburch.sora.ecrira.database.CharacterDbSchema;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CharacterLab {

    private static CharacterLab sCharacterLab;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    public static CharacterLab get(Context context){
        if(sCharacterLab == null){
            sCharacterLab = new CharacterLab(context);
        }
        return sCharacterLab;
    }

    private CharacterLab(Context context) {
        mContext = context.getApplicationContext();
        mDatabase = new CharacterBaseHelper(mContext)
                .getWritableDatabase();
    }

    public void addCharacter(Character c){
        ContentValues values = getContentValues(c);

        mDatabase.insert(CharacterDbSchema.CharacterTable.NAME, null, values);
    }

    public List<Character> getCharacters(){
        List<Character>characters = new ArrayList<>();

        CharacterCursorWrapper cursor = queryCharacters(null, null);

        try{
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                characters.add(cursor.getCharacter());
                cursor.moveToNext();
            }
        } finally{
            cursor.close();
        }
        return characters;
    }

    public Character getCharacter(UUID id){
        CharacterCursorWrapper cursor = queryCharacters(
                CharacterDbSchema.CharacterTable.Cols.UUID + " = ?",
                new String[] {id.toString()}
        );
        try{
            if(cursor.getCount() == 0){
                return null;
            }
            cursor.moveToFirst();
            return cursor.getCharacter();
        } finally{
            cursor.close();
        }
    }

    public void updateCharacter(Character character){
        String uuidString = character.getID().toString();
        ContentValues values = getContentValues(character);

        mDatabase.update(CharacterDbSchema.CharacterTable.NAME, values,
                CharacterDbSchema.CharacterTable.Cols.UUID + " = ?",
                new String[]{uuidString});
    }

    private CharacterCursorWrapper queryCharacters(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(
                CharacterDbSchema.CharacterTable.NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );
        return new CharacterCursorWrapper(cursor);
    }

    private static ContentValues getContentValues(Character character){
        ContentValues values = new ContentValues();
        values.put(CharacterDbSchema.CharacterTable.Cols.UUID, character.getID().toString());
        values.put(CharacterDbSchema.CharacterTable.Cols.FNAME, character.getFirstName());
        values.put(CharacterDbSchema.CharacterTable.Cols.LNAME, character.getLastName());
        values.put(CharacterDbSchema.CharacterTable.Cols.AGE, character.getAgeAsString());

        return values;
    }
}
