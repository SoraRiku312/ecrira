package com.williamtburch.sora.ecrira;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class CharacterListFragment extends Fragment {


    private RecyclerView mCharacterRecyclerView;
    private CharacterAdapter mAdapter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_character_list, container,
                false);
        mCharacterRecyclerView = (RecyclerView) view.findViewById(R.id.character_list_recycler_view);
        mCharacterRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

//        Character test1 = new Character();
//        test1.setFirstName("hello");
//        test1.setLastName("world");
//        test1.setAge(5);
//
//        Character test2 = new Character();
//        test1.setFirstName("foo");
//        test1.setLastName("bar");
//        test1.setAge(9);
//        CharacterLab.get(getActivity()).addCharacter(test1);
//        CharacterLab.get(getActivity()).addCharacter(test2);


        updateUI();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUI();

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_character_list, menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_character:
                Character character = new Character();
                CharacterLab.get(getActivity()).addCharacter(character);
                Intent intent = CharacterActivity.newIntent(getActivity(), character.getID());
                startActivity(intent);
                return true;
            case R.id.search_button:
                return true;  //// implement later
            default:
                return super.onOptionsItemSelected(item);


        }
    }

    private void updateUI() {
        CharacterLab characterLab = CharacterLab.get(getActivity());
        List<Character> characters = characterLab.getCharacters();
        if (mAdapter == null) {
            mAdapter = new CharacterAdapter(characters);
            mCharacterRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.setCharacters(characters);
            mAdapter.notifyDataSetChanged();
        }
    }


    private class CharacterHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private Character mCharacter;

        private TextView mNameTextView;
        private TextView mAgeTextView;
        private String mFullName;

        public CharacterHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_character, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = (TextView) itemView.findViewById(R.id.character_name);
            mAgeTextView = (TextView) itemView.findViewById(R.id.character_age);
        }

        public void bind(Character character) {
            mCharacter = character;
            if (mCharacter.getLastName() != null) {
                mNameTextView.setText(mCharacter.getFirstName() + mCharacter.getLastName());
            } else {
                mNameTextView.setText(mCharacter.getFirstName());
            }
            if (mCharacter.getAge() != 0) {
                mAgeTextView.setText(mCharacter.getAgeAsString());
            } else {
                mAgeTextView.setVisibility(View.INVISIBLE);
            }

        }

        @Override
        public void onClick(View view) {
            Intent intent = CharacterActivity.newIntent(getActivity(), mCharacter.getID());
            startActivity(intent);
        }
    }

    private class CharacterAdapter extends RecyclerView.Adapter<CharacterHolder> {

        private List<Character> mCharacters;

        public CharacterAdapter(List<Character> characters) {
            mCharacters = characters;
        }

        @Override
        public CharacterHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());

            return new CharacterHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(CharacterHolder holder, int position) {
            Character character = mCharacters.get(position);
            holder.bind(character);
        }

        @Override
        public int getItemCount() {
            return mCharacters.size();
        }

        public void setCharacters(List<Character> characters) {
            mCharacters = characters;
        }
    }
}

//    private class CharacterAdapter extends GroupAdapter<CharacterHolder>{
//
//        private List<Character> mCharacters;
//
//        public CharacterAdapter(List<Character> characters){
//            mCharacters = characters;
//        }
//
//        public void setCharacters(List<Character> characters){
//            mCharacters = characters;
//        }
//
//    }
//}
